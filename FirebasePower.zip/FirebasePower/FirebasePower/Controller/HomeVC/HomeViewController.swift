//
//  ViewController.swift
//  FirebasePower
//
//  Created by piyush sinroja on 23/02/17.
//  Copyright © 2017 Piyush. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK:-  Button Action
    @IBAction func menuButtonTouched(_ sender: Any) {
        self.findHamburguerViewController()?.showMenuViewController()
    }
}
