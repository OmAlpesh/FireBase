//
//  AboutUsViewController.swift
//  Kitchen🍴Credencys
//
//  Created by piyush sinroja on 22/06/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit

class AboutUsViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
   @IBAction func btnMenuActionAboutClass(_ sender: AnyObject) {
         self.findHamburguerViewController()?.showMenuViewController()
   }
}
