//
//  GallaryViewController.swift
//  Kitchen🍴Credencys
//
//  Created by piyush sinroja on 22/06/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit

class GallaryViewController: UIViewController {
    // MARK: - ViewController Object
     var collectionCellobject : GallaryCollectionViewCell = GallaryCollectionViewCell()
    
    fileprivate var selectedImageIndex: Int = 0
    var images = [UIImage]()
    
    // MARK: - CollectionView Otlet
    @IBOutlet weak var collectionViewGallary: UICollectionView!
    
    // MARK: - viewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        for _ in 0...9 {
            images.append(UIImage(named: "Indianpunjabi")!)
        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Button Action
    @IBAction func btnMenuAction(_ sender: AnyObject) {
        self.findHamburguerViewController()?.showMenuViewController()
    }
    
    func openImageFromImageview(image: UIImage) {
        let xibView = Bundle.main.loadNibNamed("ViewForImageZoom", owner: self, options: nil)?[0] as! ViewForImageZoom
        xibView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        let win:UIWindow = UIApplication.shared.delegate!.window!!
        xibView.image = image
        win.addSubview(xibView)
        xibView.setupViewForTapOpenImage()
    }
    
    func openImage(imgURL: URL) {
        let xibView = Bundle.main.loadNibNamed("ViewForImageZoom", owner: self, options: nil)?[0] as! ViewForImageZoom
        xibView.frame = CGRect(x: 0, y: 0, width: self.view.frame.size.width, height: self.view.frame.size.height)
        xibView.imageURL = imgURL
        let win:UIWindow = UIApplication.shared.delegate!.window!!
        win.addSubview(xibView)
        xibView.setupViewForPinch()
    }
}

// MARK: - CollectionView DataSource Method
extension GallaryViewController: UICollectionViewDataSource
{
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return 5
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        collectionCellobject = collectionView.dequeueReusableCell(withReuseIdentifier: "gallarycell", for: indexPath as IndexPath) as! GallaryCollectionViewCell
        collectionCellobject.imgviewGallary.image = UIImage(named:  "Indianpunjabi")
        return collectionCellobject
    }
}

// MARK: - CollectionView Delegate Method
extension GallaryViewController: UICollectionViewDelegate
{
//    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
//        let image = UIImage(named:  "Indianpunjabi")
//        if image != nil {
//            openImageFromImageview(image: image!)
//        }
//    }
    
     func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        selectedImageIndex = indexPath.row
        
        if let cell = collectionView.cellForItem(at: indexPath) as? GallaryCollectionViewCell {
            if let viewController = BDFPostPhotoViewerController(referencedView: cell.imgviewGallary, image: cell.imgviewGallary.image) {
                viewController.dataSource = self
                viewController.delegate = self
                self.present(viewController, animated: true, completion: nil)
            }
        }
    }

}

// MARK: - CollectionViewDelegateFlowLayout Method
extension GallaryViewController : UICollectionViewDelegateFlowLayout
{
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        return CGSize(width: collectionViewGallary.frame.width/2-5, height: 150)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        return UIEdgeInsetsMake(0, 0, 0, 0);
    }
}

// MARK: - DTPhotoViewerControllerDataSource Method
extension GallaryViewController: DTPhotoViewerControllerDataSource {
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, configureCell cell: DTPhotoCollectionViewCell, forPhotoAt index: Int) {
        // No need to implement
    }
    
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, referencedViewForPhotoAt index: Int) -> UIView? {
        let indexPath = IndexPath(item: index, section: 0)
        if let cell = collectionViewGallary.cellForItem(at: indexPath) as? GallaryCollectionViewCell {
            return cell.imgviewGallary
        }
        
        return nil
    }
    
    func numberOfItems(in photoViewerController: DTPhotoViewerController) -> Int {
        return images.count
    }
    
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, configurePhotoAt index: Int, withImageView imageView: UIImageView) {
        imageView.image = images[index]
    }
}

// MARK: - DTPhotoViewerControllerDelegate Method
extension GallaryViewController: DTPhotoViewerControllerDelegate {
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, didScrollToPhotoAt index: Int) {
        selectedImageIndex = index
    }
    
    func photoViewerControllerDidEndPresentingAnimation(_ photoViewerController: DTPhotoViewerController) {
        photoViewerController.scrollToPhoto(at: selectedImageIndex, animated: false)
        
        // Show layer
        (photoViewerController as? BDFPostPhotoViewerController)?.showCancelButton(animated: true)
    }
    
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, didZoomOnPhotoAtIndex: Int, atScale zoomScale: CGFloat) {
        if zoomScale == 1 {
            (photoViewerController as? BDFPostPhotoViewerController)?.showCancelButton(animated: true)
        }
        else {
            (photoViewerController as? BDFPostPhotoViewerController)?.hideCancelButton(animated: false)
        }
    }
    
    func photoViewerControllerDidReceiveTapGesture(_ photoViewerController: DTPhotoViewerController) {
        (photoViewerController as? BDFPostPhotoViewerController)?.reverseCancelButtonDisplayStatus()
    }
    
    func photoViewerControllerDidReceiveDoubleTapGesture(_ photoViewerController: DTPhotoViewerController) {
        (photoViewerController as? BDFPostPhotoViewerController)?.hideCancelButton(animated: false)
    }
    
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, didEndPanGestureRecognizer gestureRecognizer: UIPanGestureRecognizer) {
        
    }
    
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, willBeginPanGestureRecognizer gestureRecognizer: UIPanGestureRecognizer) {
        (photoViewerController as? BDFPostPhotoViewerController)?.hideCancelButton(animated: false)
    }
    
    func photoViewerController(_ photoViewerController: DTPhotoViewerController, scrollViewDidScroll scrollView: UIScrollView) {
        
    }
}
