//
//  EditProfileViewController.swift
//  Kitchen🍴Credencys
//
//  Created by piyush sinroja on 08/07/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit
import MobileCoreServices
import Firebase

class EditProfileViewController: UIViewController {

    // MARK: -  View Outlet
    @IBOutlet weak var viewOnScroll: UIView!
    
    // MARK: -  ScrollView Outlet
    @IBOutlet weak var scrollViewMain: UIScrollView!
    
    // MARK: -  ImageView Outlet
    @IBOutlet weak var imgViewProfile: RemoteImageView!

    // MARK: -  Textfield Outlet
    @IBOutlet weak var txtName: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    
    // MARK: -  Button Outlet
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var btnUploadPhoto: UIButton!
    
    var validationDic: NSDictionary!
    var validationmessageDic: NSDictionary!
    
    var dicUserDetails: NSDictionary?
    
    var messages: [FIRDataSnapshot]! = []
    var _refHandle: FIRDatabaseHandle!

     var imgdata : Data?
    
    // MARK: -   Other
    var activeField: UITextField!
    
    // MARK: -  viewDidLoad Outlet
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        StrucBorderColor.Bordercolor(obje: btnSubmit)
        NotificationCenter.default.addObserver(self, selector: #selector(EditProfileViewController.keyboardWasShown(aNotification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(EditProfileViewController.keyboardWillBeHidden(aNotification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    
    
    override func viewWillAppear(_ animated: Bool) {
        if let useragain = FIRAuth.auth()?.currentUser {
            if let name = useragain.displayName {
                txtName.text = name
            }
            if let urlphoto = useragain.photoURL {
               imgViewProfile.imageURL = urlphoto
            }
        }
        configureDatabase()
    }
    
    // MARK: -   viewDidLayoutSubviews
    override func viewDidLayoutSubviews() {
        imgViewProfile.layer.cornerRadius = imgViewProfile.frame.size.width/2
        imgViewProfile.layer.masksToBounds = true
        btnUploadPhoto.layer.cornerRadius = imgViewProfile.frame.size.width/2
        btnUploadPhoto.layer.masksToBounds = true
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: -  Button Actions
    @IBAction func btnBack(_ sender: AnyObject) {
        _ = navigationController?.popViewController(animated: true)
    }

    @IBAction func btnUploadPhoto(_ sender: AnyObject) {
        //Create the AlertController
        let actionSheetController: UIAlertController = UIAlertController(title: "Select Photo", message: "", preferredStyle: .actionSheet)
        
        //Create and add the Cancel action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
            //Just dismiss the action sheet
        }
        actionSheetController.addAction(cancelAction)
        //Create and add first option action
        let takePictureAction: UIAlertAction = UIAlertAction(title: "Take Photo", style: .default)
        { action -> Void in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
                imagePicker.allowsEditing = false
                imagePicker.showsCameraControls = true
                imagePicker.mediaTypes = [kUTTypeImage as String]
                self.present(imagePicker, animated: true, completion: nil)
            }
            
        }
        actionSheetController.addAction(takePictureAction)
        //Create and add a second option action
        let choosePictureAction: UIAlertAction = UIAlertAction(title: "Choose Photo", style: .default)
        { action -> Void in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
                imagePicker.allowsEditing = true
                imagePicker.mediaTypes = [kUTTypeImage as String]
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        
        actionSheetController.addAction(choosePictureAction)
        
        //We need to provide a popover sourceView when using it on iPad
        actionSheetController.popoverPresentationController?.sourceView = sender as? UIView
        
        //Present the AlertController
        self.present(actionSheetController, animated: true, completion: nil)
    }

    @IBAction func btnSubmit(_ sender: AnyObject) {
        CheckTextfieldValidation(senderstr: "btnSubmit")
    }
    
    func CheckTextfieldValidation(senderstr: String){
        validationDic = ["Name" : txtName.text!, "Mobile" : txtMobile.text!]
        validationmessageDic = ["Name" : alertmessage.Firstname, "Mobile" :alertmessage.MobileNo]
        let check: Bool =   Constant.CheckAllTextValidation(dictextfield: validationDic, dicValidationmessage: validationmessageDic)
        if check == true {
            Constant.alertView(strTitle: alertmessage.Apptitle, strMessage:"Successful")
            imageAndBasicDetail()
        }
        else {
            return
        }
    }
    
    func UpdateDetailToDatabase() {
        let user = FIRAuth.auth()?.currentUser
        let refUserProfile = FIRDatabase.database().reference(withPath: "ProfileDetails")
        let profileItemRef = refUserProfile.child((user?.uid)!)
        let data = ["Mobile": txtMobile.text]
        profileItemRef.setValue(data)
    }

    func configureDatabase() {
            let ref = FIRDatabase.database().reference()
            let user = FIRAuth.auth()?.currentUser
           _refHandle = ref.child("ProfileDetails").child((user?.uid)!).observe(.value, with: { [weak self] (snapshot) -> Void in
                guard let strongSelf = self else { return }
                self?.messages = []
                strongSelf.messages.append(snapshot)
                print(strongSelf.messages)
    
                if let messageSnapshot: FIRDataSnapshot = self?.messages[0] {
                   if let dicDetails: NSDictionary = messageSnapshot.value as? NSDictionary
                   {
                      print(dicDetails)
                      self?.dicUserDetails = dicDetails
                      self?.userDetailDisplay()
                  }
                }
            })
        }
    
    func userDetailDisplay() {
        if dicUserDetails != nil
        {
           txtMobile.text =  dicUserDetails?.object(forKey: "Mobile") as! String?
        }
    }
    
    func imageAndBasicDetail() {
        let filePath = FIRAuth.auth()!.currentUser!.uid + "/profileImage"
        if self.imgdata != nil {
            self.uploadImageToFireBaseStorage(imgData: self.imgdata!, to: filePath)
        }
        else {
            self.UpdateOtherDetails()
        }
    }
    
    func UpdateOtherDetails() {
        let user = FIRAuth.auth()?.currentUser
        if let user = user {
            let changeRequest = user.profileChangeRequest()
            changeRequest.displayName = txtName.text
            
            changeRequest.commitChanges { error in
                if error != nil {
                    
                } else {
                    self.UpdateDetailToDatabase()
                }
            }
        }
    }
    
    /// Upload image
    func uploadImageToFireBaseStorage(imgData: Data,to filePath:String)  {
        let storageRef = FIRStorage.storage().reference()
        storageRef.child(filePath).put(imgData, metadata: nil)
        { (metaData, error) in
            if let error = error
            {
                print("Error uploading: \(error)")
                self.showAlertWithMessage("Upload Failed")
                return
            }
            self.uploadSuccess(metaData!, storagePath: filePath)
        }
    }
    
    func uploadSuccess(_ metadata: FIRStorageMetadata, storagePath: String) {
        self.showAlertWithMessage("Upload Success")
        let user = FIRAuth.auth()?.currentUser
        if let user = user {
            let changeRequest = user.profileChangeRequest()
            changeRequest.displayName = txtName.text
            changeRequest.photoURL =
                NSURL(string: (metadata.downloadURL()?.absoluteString)! as String) as URL?
            changeRequest.commitChanges { error in
                if error != nil {
                    
                } else {
                     self.UpdateDetailToDatabase()
                }
            }
        }
    }
    

    // MARK: - Keyboard Notification Method
    func keyboardWasShown(aNotification: NSNotification) {
        var info = aNotification.userInfo!
        let kbSize: CGSize = (info[UIKeyboardFrameBeginUserInfoKey]! as AnyObject).cgRectValue.size
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height+5 , 0.0)
        scrollViewMain.contentInset = contentInsets
        scrollViewMain.scrollIndicatorInsets = contentInsets
        var aRect: CGRect = self.view.frame
        aRect.size.height -= kbSize.height
    }
    
    // Called when the UIKeyboardWillHideNotification is sent
    func keyboardWillBeHidden(aNotification: NSNotification) {
        UIView.animate(withDuration: 0.5, animations: {() -> Void in
            let contentInsets: UIEdgeInsets = .zero
            self.scrollViewMain.contentInset = contentInsets
            self.scrollViewMain.scrollIndicatorInsets = contentInsets
        }, completion: {(finished: Bool) -> Void in
        })
    }
}

// MARK: -  ImagePicker Method
extension EditProfileViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("didFinishPickingMediaWithInfo")
        let imageProfile = (info[UIImagePickerControllerOriginalImage] as! UIImage)
        dismiss(animated: true) {
            self.imgViewProfile?.image = imageProfile
            self.imgdata = UIImageJPEGRepresentation(imageProfile, 0.5)!
        }
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}


// MARK: - TextField Delegate Method
extension EditProfileViewController: UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeField = textField;
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeField = nil;
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if activeField == txtName {
            txtMobile.becomeFirstResponder()
        }
        else if activeField == txtMobile{
            textField.resignFirstResponder()
        }
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        textField.autocorrectionType = .no;
        return true
    }
}

