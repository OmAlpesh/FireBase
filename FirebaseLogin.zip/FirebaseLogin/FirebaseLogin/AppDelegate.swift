//
//  AppDelegate.swift
//  FirebaseLogin
//
//  Created by ithelp on 08/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import Firebase
import GoogleSignIn
import FBSDKLoginKit
import Fabric
import TwitterKit

@UIApplicationMain

class AppDelegate: UIResponder, UIApplicationDelegate, GIDSignInDelegate {
    
    var window: UIWindow?
    public var vc : GithubSignInViewController?
    
    func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
        // Override point for customization after application launch.
        
        //Use Firebase library to configure APIs
        FIRApp.configure()
        
        //For Google sign-in
        GIDSignIn.sharedInstance().clientID = "650053726825-ckglf7fufbgcgnum7jdjr4k7mqfv8jlp.apps.googleusercontent.com"
        GIDSignIn.sharedInstance().delegate = self
        
        //Configure facebook
        FBSDKApplicationDelegate.sharedInstance().application(application, didFinishLaunchingWithOptions: launchOptions)
        
        //Configure Twitter
        Fabric.with([Twitter.self])
        
        return true
    }
    
    @available(iOS 9.0, *)
    func application(_ application: UIApplication, open url: URL, options: [UIApplicationOpenURLOptionsKey : Any])
        -> Bool {
            
            let handledFireBase = GIDSignIn.sharedInstance().handle(url,
                                                                    sourceApplication:options[UIApplicationOpenURLOptionsKey.sourceApplication] as? String,
                                                                    annotation: [:])
            
            let handledFacebook = FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: options[UIApplicationOpenURLOptionsKey.sourceApplication] as? String, annotation: [:])
            
            if "firebaselogin" == url.scheme {
                
                self.vc?.oauth2.handleRedirectURL(url)
                return true
            }
            
            return (handledFireBase || handledFacebook)
    }
    
    func application(_ application: UIApplication, open url: URL, sourceApplication: String?, annotation: Any) -> Bool {
        
        let handledFacebook = FBSDKApplicationDelegate.sharedInstance().application(application, open: url, sourceApplication: sourceApplication, annotation: annotation)
        
        
        let handledFireBase = GIDSignIn.sharedInstance().handle(url,
                                                                sourceApplication: sourceApplication,
                                                                annotation: annotation)
        
        return (handledFacebook || handledFireBase)
    }
    
    
    //In the app delegate, implement the GIDSignInDelegate protocol to handle the sign-in process by defining the following methods:
    func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!, withError error: Error?) {
        
        if error != nil {
            
            return
        }
        
        guard let authentication = user.authentication else { return }
        let credential = FIRGoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                          accessToken: authentication.accessToken)
        
        FIRAuth.auth()?.signIn(with: credential) { (user, error) in
            
            if let err:Error = error {
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                
                return
            }
            
            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
        }
    }
    
    func sign(_ signIn: GIDSignIn!, didDisconnectWith user:GIDGoogleUser!,
              withError error: Error!) {
        
    }
}

extension AppDelegate {
    
    func showAlertWithMessage(_ message: String) {
        let alertController = UIAlertController(title: "Message", message:message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil))
        
        
        self.window?.rootViewController?.present(alertController, animated: true, completion: nil)
    }
    
}

extension UIApplication {
    class func topViewController(base: UIViewController? = UIApplication.shared.keyWindow?.rootViewController) -> UIViewController? {
        if let nav = base as? UINavigationController {
            return topViewController(base: nav.visibleViewController)
        }
        if let tab = base as? UITabBarController {
            if let selected = tab.selectedViewController {
                return topViewController(base: selected)
            }
        }
        if let presented = base?.presentedViewController {
            return topViewController(base: presented)
        }
        return base
    }
}
