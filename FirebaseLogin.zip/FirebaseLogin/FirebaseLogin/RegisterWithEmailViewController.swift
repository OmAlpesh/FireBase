//
//  RegisterWithEmailViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 14/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import Firebase

class RegisterWithEmailViewController: UIViewController {

    // MARK:- Vars
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    

    // MARK:- Actions
    @IBAction func registerAction(_ sender: Any) {
        
        if (self.txtEmail.text?.characters.count == 0) || (self.txtPassword.text?.characters.count == 0) {
            
            self.showAlertWithMessage("Add email or password")
            
            return
        }
        
        authWithFirebase()
    }
    
    // MARK:- Viewcontroller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebase() {
        
        FIRAuth.auth()!.createUser(withEmail: self.txtEmail.text!, password: self.txtPassword.text!) { (user, error) in
            
            if let err:Error = error {
                self.showAlertWithMessage("Register Unsuccessful :( \n Error \(err.localizedDescription)")
                
                return
            }
            
            self.showAlertWithMessage("Register successful!\n Your User id is \(user?.uid)")
        }
    }
    
}
