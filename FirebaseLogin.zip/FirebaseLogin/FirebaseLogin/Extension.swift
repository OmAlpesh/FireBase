//
//  UIWindowExtensions.swift
//  EZSwiftExtensions
//
//  Created by Gajjar Tejas on 21/5/16.
//  Copyright © 2016 Goktug Yilmaz. All rights reserved.
//

import UIKit

extension FileManager {
    
    class func filePath(fileName : String) -> URL {
        
        let paths = URL(fileURLWithPath: NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0])
        
        let getImagePath = paths.appendingPathComponent(fileName as String)
        
        return getImagePath
    }
}

extension UINavigationController {
    
    func contain<T>(viewControllerType:T.Type, in navigationController : UINavigationController) -> (isContain :Bool, viewController : AnyObject?) {
        
        var isContain = false
        
        for viewController in navigationController.viewControllers {
            if viewController is T {
                isContain = true
                return (isContain,viewController)
            }
        }
        
        return (isContain,nil)
        
    }
}

extension UIViewController {
    
    func showAlertWithMessage(_ message: String) {
        let alertController = UIAlertController(title: "Message", message:message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}
