//
//  TwitterSignInViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 13/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import TwitterKit
import Firebase

class TwitterSignInViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Login with twitter
        let logInButton = TWTRLogInButton(logInCompletion: { session, error in
            
            if (session != nil) {
                
                self.authWithFirebase(session: session)
                
            } else {
                
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(error?.localizedDescription)")
            }
        })
        
        logInButton.center = self.view.center
        self.view.addSubview(logInButton)
        
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebase(session: TWTRSession?){
        
        let credential = FIRTwitterAuthProvider.credential(withToken: (session?.authToken)!, secret: (session?.authTokenSecret)!)
        
        FIRAuth.auth()?.signIn(with: credential) { (user, error) in
            
            if let err:Error = error {
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                
                return
            }
            
            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
            
        }
    }
}
