//
//  FacebookSignInViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 13/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import FBSDKLoginKit
import Firebase

class FacebookSignInViewController: UIViewController,FBSDKLoginButtonDelegate {
    
    override func viewDidLoad() {
        super.viewDidLoad()

        //Create facebook login button
        let btnLogin = FBSDKLoginButton()
        
        self.view.addSubview(btnLogin)
        
        btnLogin.center = self.view.center
        
        //Assign delegate
        btnLogin.delegate = self
    }

    //Facebook login button delegate
    func loginButton(_ loginButton: FBSDKLoginButton!, didCompleteWith result: FBSDKLoginManagerLoginResult!, error: Error!) {
        
        if let error = error {
            
            self.showAlertWithMessage("Login Unsuccessful :( \n Error \(error.localizedDescription)")
            
            return
        }
        
        authWithFirebase()
    }
    
    
    func loginButtonDidLogOut(_ loginButton: FBSDKLoginButton!) {
        
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebase() {
        
        //Now login with Firebase
        let credential = FIRFacebookAuthProvider.credential(withAccessToken: FBSDKAccessToken.current().tokenString)
        
        FIRAuth.auth()?.signIn(with: credential) { (user, error) in
            
            if let err:Error = error {
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                
                return
            }
            
            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
        }
        
    }
}
