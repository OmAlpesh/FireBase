//
//  ProfileViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 14/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import Firebase
import FirebaseStorage
import DKImagePickerController
import SDWebImage

class ProfileViewController: UIViewController {
    
    // MARK:- Vars
    let refUserProfile = FIRDatabase.database().reference(withPath: "user-profile")
    
    var storageRef = FIRStorage.storage().reference()
    
    let user = FIRAuth.auth()?.currentUser
    
    @IBOutlet weak var imageCover: UIImageView!
    
    @IBOutlet weak var imageProfile: UIImageView!
    
    @IBOutlet weak var txtFirstName: UITextField!
    
    @IBOutlet weak var txtLastName: UITextField!
    
    @IBOutlet weak var txtHomePhone: UITextField!
    
    @IBOutlet weak var txtWorkPhone: UITextField!
    
    @IBOutlet weak var lblemail: UILabel!
    
    @IBOutlet weak var lblisAnonymous: UILabel!
    
    @IBOutlet weak var lblisEmailVerified: UILabel!
    
    @IBOutlet weak var lblphotoURL: UILabel!
    
    @IBOutlet weak var lbluid: UILabel!
    
     // MARK:- Actions
    @IBAction func chatAction(_ sender: Any) {
        
        
    }
    
    @IBAction func editCoverImageAction(_ sender: Any) {
        
        let pickerController = DKImagePickerController()
        
        pickerController.singleSelect = true
        
        pickerController.didSelectAssets = { (assets: [DKAsset]) in
            
            if assets.count > 0 {
                
                let asset = assets.first
                
                asset?.originalAsset?.requestContentEditingInput(with: nil, completionHandler: { (contentEditingInput, info) in
                    
                    let imageFile = contentEditingInput?.fullSizeImageURL
                    
                    //let filePath = FIRAuth.auth()!.currentUser!.uid + "/\(Int(Date.timeIntervalSinceReferenceDate * 1000))/\(imageFile!.lastPathComponent)"
                    
                    let filePath = FIRAuth.auth()!.currentUser!.uid + "/cover"
                    
                    self.upload(imageFile: imageFile!, to: filePath)
                    
                })
            }
        }
        
        self.present(pickerController, animated: true) {}
    }
    
    @IBAction func editProfileImageAction(_ sender: Any) {
        
        let pickerController = DKImagePickerController()
        
        pickerController.singleSelect = true
        
        pickerController.didSelectAssets = { (assets: [DKAsset]) in
            
            if assets.count > 0 {
                
                let asset = assets.first
                
                asset?.originalAsset?.requestContentEditingInput(with: nil, completionHandler: { (contentEditingInput, info) in
                    
                    let imageFile = contentEditingInput?.fullSizeImageURL
                    
                    //let filePath = FIRAuth.auth()!.currentUser!.uid + "/\(Int(Date.timeIntervalSinceReferenceDate * 1000))/\(imageFile!.lastPathComponent)"
                    
                    let filePath = FIRAuth.auth()!.currentUser!.uid + "/profile"
                    
                    self.upload(imageFile: imageFile!, to: filePath)
                    
                })
            }
        }
        
        self.present(pickerController, animated: true) {}
    }
    
    @IBAction func verifyAccountAction(_ sender: Any) {
        
        if  user!.isEmailVerified {
         
            self.showAlertWithMessage("Your account already verified.")
            
            return
        }
        
        user!.sendEmailVerification { (error) in
            
            if error != nil {
                self.showAlertWithMessage((error?.localizedDescription)!)
            } else {
                self.showAlertWithMessage("Please check your email and follow link.")
            }
            
        }
    }
    
    // MARK:- ViewController Life Cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Left bar button
        let barbuttonItemL = UIBarButtonItem(title: "Logout", style: .done, target: self, action: #selector(ProfileViewController.logout))
        
        self.navigationItem.leftBarButtonItem = barbuttonItemL
        
        // Right bar button
        let barbuttonItemR = UIBarButtonItem(title: "Save", style: .done, target: self, action: #selector(ProfileViewController.saveProfileChange))
        
        self.navigationItem.rightBarButtonItem = barbuttonItemR
        
        //Observe profile change
        observeProfileChange()
        
        //Profile URL
        let filePath = FIRAuth.auth()!.currentUser!.uid + "/profile"
        
        display(imagePath: filePath, in: self.imageProfile)
        
        //Profile URL
        let filePath1 = FIRAuth.auth()!.currentUser!.uid + "/cover"
        
        display(imagePath: filePath1, in: self.imageCover)
        
        self.lblisAnonymous.text = user!.displayName
        self.lblemail.text = user!.email
        self.lblisAnonymous.text = user!.isAnonymous ?"true":"false"
        self.lblisEmailVerified.text = user!.isEmailVerified ?"true":"false"
        self.lblphotoURL.text = user!.photoURL?.absoluteString
        self.lbluid.text = user!.uid
        
    }
    
    // MARK:- Others
    func observeProfileChange()  {
        
        refUserProfile.child((user?.uid)!).observe(.value, with: { (snapshot) in
            
            print(snapshot)
            
            self.updateUI(snapshot: snapshot)
        })
    }
    
    /// Save profile
    func saveProfileChange()  {
        
        let profileItemRef = self.refUserProfile.child((user?.uid)!)
        
        profileItemRef.child("name").child("firstname").setValue(self.txtFirstName.text)
        
        profileItemRef.child("name").child("lastname").setValue(self.txtLastName.text)
        
        profileItemRef.child("phone").child("home").setValue(self.txtHomePhone.text)
        
        profileItemRef.child("phone").child("work").setValue(self.txtWorkPhone.text)
    }
    
    
    /// Update UI
    func updateUI(snapshot:FIRDataSnapshot) {
        
        if let profileDict = snapshot.value as? NSDictionary {
            
            let nameDict = profileDict.object(forKey: "name") as? NSDictionary
            
            self.txtFirstName.text = nameDict?.object(forKey: "firstname") as! String?
            self.txtLastName.text = nameDict?.object(forKey: "lastname") as! String?
            
            let phoneDict = profileDict.object(forKey: "phone") as? NSDictionary
            
            self.txtHomePhone.text = phoneDict?.object(forKey: "home") as! String?
            self.txtWorkPhone.text = phoneDict?.object(forKey: "work") as! String?
        }
    }
    
    func uploadSuccess(_ metadata: FIRStorageMetadata, storagePath: String) {
        self.showAlertWithMessage("Upload Success")
        print((metadata.downloadURL()?.absoluteString)! as String)
    }
    
    /// Upload image
    func upload(imageFile: URL,to filePath:String)  {
        
        self.storageRef.child(filePath)
            .putFile(imageFile, metadata: nil) { (metadata, error) in
                if let error = error {
                    print("Error uploading: \(error)")
                    self.showAlertWithMessage("Upload Failed")
                    return
                }
                
                self.uploadSuccess(metadata!, storagePath: filePath)
        }
    }
    
    /// Display image in imageview
    func display(imagePath:String,in imageView:UIImageView )  {
        
        // Create a reference to the file you want to download
        let starsRef = storageRef.child(imagePath)
        
        // Fetch the download URL
        starsRef.downloadURL { url, error in
            if error != nil {
                // Handle any errors
            } else {
                // Get the download URL for 'images/stars.jpg'
                imageView.sd_setImage(with: url, placeholderImage: nil)
            }
        }
    }
    
    /// Logout current user
    func logout()  {
        
        do {
            try FIRAuth.auth()!.signOut()
            
            _ = self.navigationController?.popToRootViewController(animated: true)
            
        } catch {
            
        }
    }
}
