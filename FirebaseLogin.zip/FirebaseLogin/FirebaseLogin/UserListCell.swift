//
//  UserListCell.swift
//  FirebaseLogin
//
//  Created by ithelp on 21/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit

class UserListCell: UITableViewCell {

    
    @IBOutlet weak var lblUserName: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
