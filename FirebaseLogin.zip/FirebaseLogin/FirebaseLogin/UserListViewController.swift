//
//  UserListViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 21/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import Firebase

class UserListViewController: UIViewController,UITableViewDelegate,UITableViewDataSource {
    
    @IBOutlet weak var tableView: UITableView!
    
    let refUserProfile = FIRDatabase.database().reference(withPath: "user-profile")
    
    var value = NSDictionary()
    
    // MARK:- Others
    func observeProfileChange()  {
        
        refUserProfile.observeSingleEvent(of: .value, with: { (snapshot) in
            
            self.value = (snapshot.value as? NSDictionary)!
            
            print(self.value)
            
            self.tableView.reloadData()
            
        }) { (error) in
            
            print(error.localizedDescription)
            
        }
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.delegate = self
        self.tableView.dataSource = self
        
        observeProfileChange()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    // MARK: - Table view data source
    func numberOfSections(in tableView: UITableView) -> Int {

        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {

        return self.value.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "UserListCell", for: indexPath) as! UserListCell
        
        cell.lblUserName.text = self.value.allKeys[indexPath.row] as? String
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let vc = self.storyboard?.instantiateViewController(withIdentifier: "ChatViewController") as! ChatViewController
        
        vc.userid = self.value.allKeys[indexPath.row] as! String
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
}
