//
//  GoogleSignInViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 08/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import GoogleSignIn
import Firebase

class GoogleSignInViewController: UIViewController, GIDSignInUIDelegate {
    
    override func viewDidLoad() {
        
        super.viewDidLoad()
        
        GIDSignIn.sharedInstance().uiDelegate = self
    }
    
    
    func signIn(signIn: GIDSignIn!, didSignInForUser user: GIDGoogleUser!,
                withError error: NSError!) {
        if (error == nil) {
            
            guard let authentication = user.authentication else {
                
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(error.localizedDescription)")
                
                return
            }
            
            authWithFirebase(authentication: authentication)
            
        } else {
            
            print("\(error.localizedDescription)")
            
        }
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebase(authentication: GIDAuthentication) {
        
        let credential = FIRGoogleAuthProvider.credential(withIDToken: authentication.idToken,
                                                          accessToken: authentication.accessToken)
        
        FIRAuth.auth()?.signIn(with: credential) { (user, error) in
            
            if let err:Error = error {
                
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                
                return
            }
            
            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
            
        }
    }
}
