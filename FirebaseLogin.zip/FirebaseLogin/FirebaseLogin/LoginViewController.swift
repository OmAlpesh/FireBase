//
//  ViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 08/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        observeLoginStateChange()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //Mark:- Login
    @IBAction func loginAnonymously(_ sender: Any) {
        
        FIRAuth.auth()?.signInAnonymously(completion: { (user, error) in
            
            if let err:Error = error {
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                
                return
            }
            
            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
        })
    }
    
    @IBAction func loginWithEmail(_ sender: Any) {
        
    }
    
    @IBAction func loginWithGoogle(_ sender: Any) {
        
    }
    
    @IBAction func loginWithFacebook(_ sender: Any) {
        
    }
    
    func observeLoginStateChange() {
        
        FIRAuth.auth()!.addStateDidChangeListener() { auth, user in
            
            guard let _ = user else {
                
                return
            }
            
            let vcContain =   self.navigationController?.contain(viewControllerType: ProfileViewController.self
                , in: self.navigationController!)
            
            
            if !(vcContain?.isContain)! {
                
                let vc = self.storyboard?.instantiateViewController(withIdentifier: "ProfileViewController")
                
                self.navigationController?.pushViewController(vc!, animated: true)
            }
        }
    }
}

