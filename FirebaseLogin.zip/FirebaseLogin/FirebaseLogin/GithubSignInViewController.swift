//
//  GithubSignInViewController.swift
//  FirebaseLogin
//
//  Created by ithelp on 13/02/17.
//  Copyright © 2017 ithelp. All rights reserved.
//

import UIKit
import Firebase
import p2_OAuth2

class GithubSignInViewController: UIViewController {
    
    // MARK:- Vars
    public let oauth2 = OAuth2CodeGrant(settings: [
        "client_id": "f0d805c62cf56c3251ff",
        "client_secret": "8bcb8e36d981886370bb37f3281c62b7d7ade331",
        "authorize_uri": "https://github.com/login/oauth/authorize",
        "token_uri": "https://github.com/login/oauth/access_token",   // code grant only
        "redirect_uris": ["firebaselogin://oauth/callback"],   // register your own "myapp" scheme in Info.plist
        "scope": "user repo:status",
        "secret_in_body": true,    // Github needs this
        "keychain": false,         // if you DON'T want keychain integration
        ] as OAuth2JSON)
    
    
    // MARK:- Viewcontroller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    // MARK:- Actions
    @IBAction func loginWithGithub(_ sender: Any) {
        
        if let appdel = UIApplication.shared.delegate as? AppDelegate {
            
            appdel.vc = self
        }
        
        oauth2.authConfig.authorizeEmbedded = true
        oauth2.authConfig.authorizeContext = self
        //oauth2.logger = OAuth2DebugLogger(.trace)
        
        //Let the Data Loader or Alamofire Take Over
        let base = URL(string: "https://api.github.com")!
        let url = base.appendingPathComponent("user")
        
        var req = oauth2.request(forURL: url)
        req.setValue("application/vnd.github.v3+json", forHTTPHeaderField: "Accept")
        
        let loader = OAuth2DataLoader(oauth2: oauth2)
        loader.perform(request: req) { response in
            
            do {
                self.authWithFirebase()
                
                //throw s
                
            }
                
            catch let error {
                DispatchQueue.main.async {
                    self.showAlertWithMessage("Login Unsuccessful :( \n Error \(error.localizedDescription)")
                }
            }
        }
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebase() {
        
        let credential = FIRGitHubAuthProvider.credential(withToken: self.oauth2.accessToken!)
        
        FIRAuth.auth()?.signIn(with: credential) { (user, error) in
            
            if let err:Error = error {
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                
                return
            }
            
            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
        }
    }
}
