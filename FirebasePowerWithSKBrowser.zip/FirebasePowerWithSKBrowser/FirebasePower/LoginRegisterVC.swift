//
//  LoginRegisterVC.swift
//  FirebasePower
//
//  Created by piyush sinroja on 23/02/17.
//  Copyright © 2017 Piyush. All rights reserved.
//

import UIKit
import Firebase

class LoginRegisterVC: UIViewController {
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    @IBOutlet weak var lblName: UILabel!
    @IBOutlet weak var imgView: RemoteImageView?
    
    @IBOutlet weak var txtName: UITextField!
    var imgdata : Data?
    
    @IBOutlet weak var switchLR: UISwitch!
    
    @IBOutlet weak var constrBtnLoginTop: NSLayoutConstraint!
    @IBOutlet weak var btnLogin: UIButton!
    @IBOutlet weak var btnRegister: UIButton!
    
//
//    let filePath = FIRAuth.auth()!.currentUser!.uid + "/profileImage"
    
    override func viewDidLoad() {
        super.viewDidLoad()
        switchLR.setOn(false, animated: true)
        btnLogin.isHidden = true
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func btnRegister(_ sender: Any) {
        validationRegister()
        authWithFirebaseRegister()
    }
    
    @IBAction func btnLogin(_ sender: Any) {
        validationLogin()
        authWithFirebaseLogin()
    }
    
    func validationLogin()  {
        if (self.txtEmail.text?.characters.count == 0) || (self.txtPassword.text?.characters.count == 0) {
            self.showAlertWithMessage("Add email or password")
            return
        }
    }
    
    func validationRegister()  {
        if btnRegister.title(for: .normal) == "Update" {
            imageAndBasicDetail()
        }
        else {
            if (self.txtEmail.text?.characters.count == 0) || (self.txtPassword.text?.characters.count == 0) || (self.txtName.text?.characters.count == 0) {
                self.showAlertWithMessage("Add email or password or Name")
                return
            }
        }
    }

    // MARK:- Auth with Firebase account
    func authWithFirebaseLogin() {
        FIRAuth.auth()?.signIn(withEmail: self.txtEmail.text!, password: self.txtPassword.text!, completion: { (user, error) in
            if let err:Error = error
            {
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                return
            }

            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
            if let useragain = FIRAuth.auth()?.currentUser {
                print(useragain.displayName ?? "")
                print(useragain.uid)
                print(useragain.email ?? "")
                print(useragain.photoURL ?? "")
                
                if let name = useragain.displayName {
                    self.lblName.text = name
                }
            
                if let urlphoto = useragain.photoURL
                {
                    self.imgView?.imageURL = urlphoto
                }
                self.btnRegister.setTitle("Update", for: .normal)
            }
        })
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebaseRegister() {
        FIRAuth.auth()!.createUser(withEmail: self.txtEmail.text!, password: self.txtPassword.text!) { (user, error) in
            if let err:Error = error {
                self.showAlertWithMessage("Register Unsuccessful :( \n Error \(err.localizedDescription)")
                return
            }
            self.showAlertWithMessage("Register successful!\n Your User id is \(user?.uid)")
            self.btnRegister.setTitle("Update", for: .normal)
            self.imageAndBasicDetail()
        }
    }
    
    func imageAndBasicDetail() {
        let filePath = FIRAuth.auth()!.currentUser!.uid + "/profileImage"
        if self.imgdata != nil {
            self.uploadImageToFireBaseStorage(imgData: self.imgdata!, to: filePath)
        }
        else {
            self.UpdateOtherDetails()
        }
    }

    func UpdateOtherDetails() {
        let user = FIRAuth.auth()?.currentUser
        if let user = user {
            let changeRequest = user.profileChangeRequest()
            changeRequest.displayName = txtName.text
            changeRequest.commitChanges { error in
                if error != nil {
                    
                } else {
                    
                }
            }
        }
    }
    
    /// Upload image
    func uploadImageToFireBaseStorage(imgData: Data,to filePath:String)  {
         let storageRef = FIRStorage.storage().reference()
        storageRef.child(filePath).put(imgData, metadata: nil)
        { (metaData, error) in
            if let error = error
            {
                print("Error uploading: \(error)")
                self.showAlertWithMessage("Upload Failed")
                return
            }
            self.uploadSuccess(metaData!, storagePath: filePath)
        }
    }
    
    func uploadSuccess(_ metadata: FIRStorageMetadata, storagePath: String) {
        self.showAlertWithMessage("Upload Success")
        let user = FIRAuth.auth()?.currentUser
        if let user = user {
            let changeRequest = user.profileChangeRequest()
            changeRequest.displayName = txtName.text
            changeRequest.photoURL =
                NSURL(string: (metadata.downloadURL()?.absoluteString)! as String) as URL?
            changeRequest.commitChanges { error in
                if error != nil {
                    
                } else {
                    
                }
            }
        }
    }
    
    @IBAction func uploadPhoto(_ sender: Any) {
        
        //Create the AlertController
        let actionSheetController: UIAlertController = UIAlertController(title: "Select Photo", message: "", preferredStyle: .actionSheet)
        
        //Create and add the Cancel action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
            //Just dismiss the action sheet
        }
        actionSheetController.addAction(cancelAction)
        //Create and add first option action
        let takePictureAction: UIAlertAction = UIAlertAction(title: "Take Photo", style: .default)
        { action -> Void in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
                imagePicker.allowsEditing = false
                imagePicker.showsCameraControls = true
                self.present(imagePicker, animated: true, completion: nil)
            }
            
        }
        actionSheetController.addAction(takePictureAction)
        //Create and add a second option action
        let choosePictureAction: UIAlertAction = UIAlertAction(title: "Choose Photo", style: .default)
        { action -> Void in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
                imagePicker.allowsEditing = true
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        
        actionSheetController.addAction(choosePictureAction)
        
        //We need to provide a popover sourceView when using it on iPad
        actionSheetController.popoverPresentationController?.sourceView = sender as? UIView
        
        //Present the AlertController
        self.present(actionSheetController, animated: true, completion: nil)
    }

    @IBAction func switchLR(_ sender: UISwitch) {
       if sender.isOn
       {
          btnRegister.isHidden = true
          btnLogin.isHidden = false
          txtName.isHidden = true
          constrBtnLoginTop.constant = 10
       }
       else
        {
            btnLogin.isHidden = true
            btnRegister.isHidden = false
            txtName.isHidden = false
            constrBtnLoginTop.constant = 70
        }
    }
}
extension UIViewController {
    func showAlertWithMessage(_ message: String) {
        let alertController = UIAlertController(title: "Message", message:message, preferredStyle: .alert)
        alertController.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.cancel, handler: nil))
        present(alertController, animated: true, completion: nil)
    }
}

extension LoginRegisterVC : UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    //MARK: - ImagePicker Delegate
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        print("imagePickerControllerDidCancel")
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("didFinishPickingMediaWithInfo")
        let imageProfile = (info[UIImagePickerControllerOriginalImage] as! UIImage)
        dismiss(animated: true) {
            
            self.imgView?.image = imageProfile
            self.imgdata = UIImageJPEGRepresentation(imageProfile, 0.5)!
        }
    }

}
