//
//  DLHamburguerNavigationController.swift
//  DLHamburguerMenu
//
//  Created by Nacho on 5/3/15.
//  Copyright (c) 2015 Ignacio Nieto Carvajal. All rights reserved.
//

import UIKit

class DLHamburguerNavigationController: UINavigationController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.view.addGestureRecognizer(UIPanGestureRecognizer(target: self, action: #selector(DLHamburguerNavigationController.panGestureRecognized(_:))))
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func pushViewFromSideMenu(senderObject: AnyObject) {
        let nvc = self
        nvc.pushViewController(senderObject as! UIViewController, animated: true)
        if let hamburguerViewController = self.findHamburguerViewController() {
            hamburguerViewController.hideMenuViewControllerWithCompletion({ () -> Void in
                //nvc.visibleViewController!.performSegueWithIdentifier(self.segues[indexPath.row], sender: nil)
                hamburguerViewController.contentViewController = nvc
            })
        }
    }

    func panGestureRecognized(_ sender: UIPanGestureRecognizer!) {
        // dismiss keyboard
               // React to recognizer
        let point = sender.translation(in: self.view)
        if point.y == 0 && point.x > 0{
            self.view.endEditing(true)
            self.findHamburguerViewController()?.view.endEditing(true)
            // pass gesture to hamburguer view controller.
            self.findHamburguerViewController()?.panGestureRecognized(sender)
        }
    }
}
