
//  Created by piyush sinroja on 27/06/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit

class Constant: NSObject {
    static var kScreenBounds    :   CGRect = UIScreen.main.bounds
    static var isiPhone_4       :   Bool   = 480 == UIScreen.main.bounds.size.height ? true:false
    static var isiPhone_5       :   Bool   = 568 == UIScreen.main.bounds.size.height ? true:false
    static var isiPhone_6       :   Bool   = 667 == UIScreen.main.bounds.size.height ? true:false
    static var isiPhone_6_Plus  :   Bool   = 736 == UIScreen.main.bounds.size.height ? true:false
    
    static let loginVC : LoginViewController = mainStoryboard.instantiateViewController(withIdentifier: "LoginViewController") as! LoginViewController
    
    static let homeVC : HomeViewController = mainStoryboard.instantiateViewController(withIdentifier: "HomeViewController") as! HomeViewController
    
    static let registerVC : RegisterViewController = mainStoryboard.instantiateViewController(withIdentifier: "RegisterViewController") as! RegisterViewController
    
    static let editProfileVC : EditProfileViewController = mainStoryboard.instantiateViewController(withIdentifier: "EditProfileViewController") as!  EditProfileViewController
    
    static let aboutUsVC : AboutUsViewController = mainStoryboard.instantiateViewController(withIdentifier: "AboutUsViewController") as!  AboutUsViewController
    
    static let gallaryVC : GallaryViewController = mainStoryboard.instantiateViewController(withIdentifier: "GallaryViewController") as!  GallaryViewController

    
    static func mainNavigationController() -> DLHamburguerNavigationController {
        return Constant.mainStoryboard.instantiateViewController(withIdentifier: "DLHamburguerNavigationController") as! DLHamburguerNavigationController
    }
    
    // MARK: -  UIStoryboard
    static var mainStoryboard = UIStoryboard(name: "Main", bundle: nil)

    // MARK: - goToViewcontroller Methods
    
    static func goToHomeViewController(selfnew: UIViewController) {
         pushViewFromSideMenu(senderObject: homeVC, selfnewobj: selfnew)
    }
    
    static func goToAboutUsViewController(selfnew: UIViewController){
        pushViewFromSideMenu(senderObject: aboutUsVC, selfnewobj: selfnew)
    }
    
    static func goToGallaryViewController(selfnew: UIViewController) {
        pushViewFromSideMenu(senderObject: gallaryVC, selfnewobj: selfnew)
    }
    static func goToOrderViewController(selfnew: UIViewController) {
        
    }
    static func goToMyCartViewController(selfnew: UIViewController) {
        
    }
    static func goToSpecialOfferViewController(selfnew: UIViewController){
        
    }
    
    static func pushViewFromSideMenu(senderObject: UIViewController,selfnewobj: UIViewController) {
        let nvc = self.mainNavigationController()
        nvc.pushViewController(senderObject, animated: true)
        if let hamburguerViewController = selfnewobj.findHamburguerViewController() {
            hamburguerViewController.hideMenuViewControllerWithCompletion({ () -> Void in
                hamburguerViewController.contentViewController = nvc
            })
        }
    }
    
    static func alertController(strTitle:String,strMessage:String, selfclass: UIViewController ){
        // Initialize Alert Controller
        let alertController = UIAlertController(title:strTitle , message:strMessage , preferredStyle: UIAlertControllerStyle.alert)
        
        // Initialize Actions
        let yesAction = UIAlertAction(title: "Cancel", style: .default){
            (action) -> Void in
            print("Cancel.")
        }
        let noAction = UIAlertAction(title: "Ok", style: .default) { (action) -> Void in
            print("Ok.")
        }
        // Add Actions
        alertController.addAction(yesAction)
        alertController.addAction(noAction)
        
        // Present Alert Controller
        DispatchQueue.main.async {
            selfclass.present(alertController, animated: true, completion: nil)
        }
    }
    
    //MARK:-  Validation
    static func CheckAllTextValidation(dictextfield: NSDictionary, dicValidationmessage: NSDictionary)-> Bool
    {
        for (key, Value) in dictextfield
        {
            let strtemp: String = "\(Value)"
            let strKey : String = "\(key)"
            switch strtemp
            {
              case strtemp:
                if strtemp.characters.count == 0 {
                    Constant.alertView(strTitle: alertmessage.Apptitle, strMessage: dicValidationmessage[key] as! String)
                    return false
                }
                else {
                    
                    switch strKey {
                    case "Mobile":
                        let checkmobile: Bool = strtemp.isMobileNumber
                        if checkmobile == false {
                            Constant.alertView(strTitle: alertmessage.Apptitle, strMessage: dicValidationmessage[strKey] as! String)
                            return false
                        }
                    case "Email":
                        let checkmail: Bool = strtemp.isEmailID
                        if checkmail == false {
                            Constant.alertView(strTitle: alertmessage.Apptitle, strMessage: dicValidationmessage[strKey] as! String)
                            return false
                        }
                    case "Password":
                        let checkmail: Bool = strtemp.isValidPassword
                        if checkmail == false {
                            Constant.alertView(strTitle: alertmessage.Apptitle, strMessage: dicValidationmessage[strKey] as! String)
                            return false
                        }
                    case "Name":
                        return true
                    default:
                        return false
                    }
                }
                break
              default:
                print("Novalidation")
                return false
            }
        }
        return true
    }
    
    //MARK:-  alertView
    static func alertView(strTitle:String,strMessage:String){
        let alert:UIAlertView = UIAlertView(title: strTitle as String, message: strMessage as String, delegate: nil, cancelButtonTitle: "ok")
        
        DispatchQueue.main.async {
            alert.show()
        }
    }
}

//MARK:- String Extension
extension String {
    //To check text field or String is blank or not
    var isBlank: Bool {
        get {
            let trimmed = trimmingCharacters(in: CharacterSet.whitespaces)
            return trimmed.isEmpty
        }
    }
    
    //Validate Email
    var isEmailID: Bool {
        do {
            let regex = try NSRegularExpression(pattern: "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}", options: .caseInsensitive)
            return regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.characters.count)) != nil
        } catch {
            return false
        }
    }
    
    var isAlphanumeric: Bool {
        return !isEmpty && range(of: "[^a-zA-Z0-9]", options: .regularExpression) == nil
    }
    
    //validate Password
    var isValidPassword: Bool {
        do {
            let regex = try NSRegularExpression(pattern: "^[a-zA-Z_0-9\\-_,;.:#+*?=!§$%&/()@]+$", options: .caseInsensitive)
            if(regex.firstMatch(in: self, options: NSRegularExpression.MatchingOptions(rawValue: 0), range: NSMakeRange(0, self.characters.count)) != nil){
                if(self.characters.count>=6 && self.characters.count<=20){
                    return true
                }else{
                    return false
                }
            }else{
                return false
            }
        } catch {
            return false
        }
    }
    
    var isValidUserName: Bool {
        // /^[A-Za-z][A-Za-z0-9 -]*$/
        let regEx = "^[A-Z][A-Za-z']"
        let match = self.range(of: regEx, options: .regularExpression, range: nil, locale: nil)
        // Usernam should not blank
        //Username should not be more than 40 characters.
        //Username should not contain space
        //Username should not start with any symbols.
        //Username should not accept with spacing word(like word:user test)
        if !self.isEmpty && !(self.characters.count <= 2) && !(self.characters.count >= 25) && !self.contains(" ") && !(match == nil) {
            return true
        }
        return false
    }
    
    var isMobileNumber: Bool {
        let numberRegEx = "[0-9]{10,15}"
        let numberTest = NSPredicate(format:"SELF MATCHES %@", numberRegEx)
        if !numberTest.evaluate(with: self){
            return false
        }
        return true
    }
}

struct alertmessage {
    static var Firstname   :   String = "Please Enter Firstname"
    static var Cityname   :   String = "Please Enter Cityname"
    static var MobileNo   :   String =  "Please Enter MobileNo"
    static var EmailId   :   String =  "Please Enter Valid EmailId"
    static var Password   :   String =  "Please Enter Password"
    static var Submited   :   String = "Details Submited SuccessFully"
    static var Apptitle   :   String = "FireBaseDemo"
    static var MobileExits   :   String = "Mobile No Already Exits"
}
