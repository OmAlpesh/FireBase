//
//  GallaryCollectionViewCell.swift
//  Kitchen🍴Credencys
//
//  Created by piyush sinroja on 22/06/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit

class GallaryCollectionViewCell: UICollectionViewCell {
        
    @IBOutlet weak var imgviewGallary: UIImageView!
}
