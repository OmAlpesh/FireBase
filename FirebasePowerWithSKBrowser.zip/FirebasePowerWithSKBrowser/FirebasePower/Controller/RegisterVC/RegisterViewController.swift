//
//  RegisterViewController.swift
//  Kitchen🍴Credencys
//
//  Created by piyush sinroja on 20/06/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit
import MobileCoreServices
import Firebase

class RegisterViewController: UIViewController {

     // MARK: -  UIView Outlet
    @IBOutlet weak var viewOnScroll: UIView!
    
    // MARK: -  UITextField Outlet
    @IBOutlet weak var txtFirstName: UITextField!
    @IBOutlet weak var txtMobile: UITextField!
    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    // MARK: -   UIImageView Outlet
    @IBOutlet weak var imgviewProfile: RemoteImageView!
    var messages: [FIRDataSnapshot]! = []
    var _refHandle: FIRDatabaseHandle!
    
    // MARK: -   Button Outlet
    @IBOutlet weak var btnSubmit: UIButton!
    @IBOutlet weak var btnUploadPhoto: UIButton!
    
    // MARK: -   UIScrollView Outlet
    @IBOutlet weak var scrollViewMain: UIScrollView!
    
     var imgdata : Data?
    
    // MARK: -   Other
    var activeField: UITextField!
    var validationDic: NSDictionary!
    var validationmessageDic: NSDictionary!

    // MARK: -   viewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()
        StrucBorderColor.Bordercolor(obje: btnSubmit)
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterViewController.keyboardWasShown(aNotification:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil)
        NotificationCenter.default.addObserver(self, selector: #selector(RegisterViewController.keyboardWillBeHidden(aNotification:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil)
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - viewDidLayoutSubviews
    override func viewDidLayoutSubviews() {
        imgviewProfile.layer.cornerRadius = imgviewProfile.frame.size.width/2
        imgviewProfile.layer.masksToBounds = true
        btnUploadPhoto.layer.cornerRadius = imgviewProfile.frame.size.width/2
        btnUploadPhoto.layer.masksToBounds = true
    }

    // MARK: -   Button Action
    @IBAction func btnSybmit(_ sender: AnyObject) {
        //createParticles()
        CheckTextfieldValidation(senderstr: "btnSubmit")
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebaseRegister() {
        FIRAuth.auth()!.createUser(withEmail: self.txtEmail.text!, password: self.txtPassword.text!) { (user, error) in
            if let err:Error = error {
                self.showAlertWithMessage("Register Unsuccessful :( \n Error \(err.localizedDescription)")
                return
            }
            self.imageAndBasicDetail()
        }
    }
    
    func imageAndBasicDetail() {
        let filePath = FIRAuth.auth()!.currentUser!.uid + "/profileImage"
        if self.imgdata != nil {
            self.uploadImageToFireBaseStorage(imgData: self.imgdata!, to: filePath)
        }
        else {
            self.UpdateOtherDetails()
        }
    }
    
    func UpdateOtherDetails() {
        let user = FIRAuth.auth()?.currentUser
        if let user = user {
            let changeRequest = user.profileChangeRequest()
            changeRequest.displayName = txtFirstName.text
            changeRequest.commitChanges { error in
                if error != nil {
                    self.showAlertWithMessage("Register successful!\n Your User id is \(user.uid)")
                } else {
                    self.UpdateDetailToDatabase()
                }
            }
        }
    }
    
    /// Upload image
    func uploadImageToFireBaseStorage(imgData: Data,to filePath:String)  {
        let storageRef = FIRStorage.storage().reference()
        storageRef.child(filePath).put(imgData, metadata: nil)
        { (metaData, error) in
            if let error = error
            {
                print("Error uploading: \(error)")
                self.showAlertWithMessage("Upload Failed")
                return
            }
            self.uploadSuccess(metaData!, storagePath: filePath)
        }
    }
    
    func UpdateDetailToDatabase() {
            let user = FIRAuth.auth()?.currentUser
            let refUserProfile = FIRDatabase.database().reference(withPath: "ProfileDetails")
            let profileItemRef = refUserProfile.child((user?.uid)!)
            let data = ["Mobile": txtMobile.text]
            profileItemRef.setValue(data)
    }

    func uploadSuccess(_ metadata: FIRStorageMetadata, storagePath: String) {
        self.showAlertWithMessage("Upload Success")
        let user = FIRAuth.auth()?.currentUser
        if let user = user {
            let changeRequest = user.profileChangeRequest()
            changeRequest.displayName = txtFirstName.text
            changeRequest.photoURL =
                NSURL(string: (metadata.downloadURL()?.absoluteString)! as String) as URL?
            changeRequest.commitChanges { error in
                if error != nil {
                    
                } else {
                    self.UpdateDetailToDatabase()
                }
            }
        }
    }
    
    @IBAction func btnUploadPhoto(_ sender: AnyObject) {
        //Create the AlertController
        let actionSheetController: UIAlertController = UIAlertController(title: "Select Photo", message: "", preferredStyle: .actionSheet)
        
        //Create and add the Cancel action
        let cancelAction: UIAlertAction = UIAlertAction(title: "Cancel", style: .cancel) { action -> Void in
            //Just dismiss the action sheet
        }
        actionSheetController.addAction(cancelAction)
        //Create and add first option action
        let takePictureAction: UIAlertAction = UIAlertAction(title: "Take Photo", style: .default)
        { action -> Void in
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.camera) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.camera;
                imagePicker.allowsEditing = false
                imagePicker.showsCameraControls = true
                imagePicker.mediaTypes = [kUTTypeImage as String]
                self.present(imagePicker, animated: true, completion: nil)
            }
            
        }
        actionSheetController.addAction(takePictureAction)
        //Create and add a second option action
        let choosePictureAction: UIAlertAction = UIAlertAction(title: "Choose Photo", style: .default)
        { action -> Void in
            
            if UIImagePickerController.isSourceTypeAvailable(UIImagePickerControllerSourceType.photoLibrary) {
                let imagePicker = UIImagePickerController()
                imagePicker.delegate = self
                imagePicker.sourceType = UIImagePickerControllerSourceType.photoLibrary;
                imagePicker.allowsEditing = true
                imagePicker.mediaTypes = [kUTTypeImage as String]
                self.present(imagePicker, animated: true, completion: nil)
            }
        }
        
        actionSheetController.addAction(choosePictureAction)
        
        //We need to provide a popover sourceView when using it on iPad
        actionSheetController.popoverPresentationController?.sourceView = sender as? UIView
        
        //Present the AlertController
        self.present(actionSheetController, animated: true, completion: nil)
    }
    
    func CheckTextfieldValidation(senderstr: String){
        
        validationDic = ["Name" : txtFirstName.text!, "Mobile" : txtMobile.text!, "Email": txtEmail.text!, "Password" : txtPassword.text!]
        validationmessageDic = ["Name" : alertmessage.Firstname, "Mobile" :alertmessage.MobileNo, "Email": alertmessage.EmailId, "Password":alertmessage.Password]
        let check: Bool =   Constant.CheckAllTextValidation(dictextfield: validationDic, dicValidationmessage: validationmessageDic)
        if check == true{
            Constant.alertView(strTitle: alertmessage.Apptitle, strMessage:"Successful")
            authWithFirebaseRegister()
        }
        else {
            return
        }
    }

    // MARK: - CAEmitterLayer Setup
    
    func createParticles() {
        let particleEmitter = CAEmitterLayer()
        
        particleEmitter.emitterPosition = CGPoint(x: view.center.x, y: -96)
        particleEmitter.emitterShape = kCAEmitterLayerLine
        particleEmitter.emitterSize = CGSize(width: view.frame.size.width, height: 1)
        
        let red = makeEmitterCellWithColor(color: UIColor.white)
       // let green = makeEmitterCellWithColor(UIColor.greenColor())
       // let blue = makeEmitterCellWithColor(UIColor.blueColor())
        
        particleEmitter.emitterCells = [red]
        
        view.layer.addSublayer(particleEmitter)
    }
    
    func makeEmitterCellWithColor(color: UIColor) -> CAEmitterCell {
        let cell = CAEmitterCell()
        cell.birthRate = 3
        cell.lifetime = 7.0
        cell.lifetimeRange = 0
        cell.color = color.cgColor
        cell.velocity = 200
        cell.velocityRange = 200
        cell.emissionLongitude = CGFloat(M_PI)
        cell.emissionRange = CGFloat(M_PI_4)
        cell.spin = 0
        cell.spinRange = 3
        cell.scaleRange = 0.5
        cell.scaleSpeed = -0.05
        
        cell.contents = UIImage(named: "spark.png")?.cgImage
        return cell
    }

    // MARK: - Keyboard Notification Method
    func keyboardWasShown(aNotification: NSNotification) {
        var info = aNotification.userInfo!
        let kbSize: CGSize = (info[UIKeyboardFrameBeginUserInfoKey]! as AnyObject).cgRectValue.size
        let contentInsets: UIEdgeInsets = UIEdgeInsetsMake(0.0, 0.0, kbSize.height+5 , 0.0)
        scrollViewMain.contentInset = contentInsets
        scrollViewMain.scrollIndicatorInsets = contentInsets
        var aRect: CGRect = self.view.frame
        aRect.size.height -= kbSize.height
    }
    
    // Called when the UIKeyboardWillHideNotification is sent
    func keyboardWillBeHidden(aNotification: NSNotification) {
        UIView.animate(withDuration: 0.5, animations: {() -> Void in
            let contentInsets: UIEdgeInsets = .zero
            self.scrollViewMain.contentInset = contentInsets
            self.scrollViewMain.scrollIndicatorInsets = contentInsets
            }, completion: {(finished: Bool) -> Void in
        })
    }
}

// MARK: -  ImagePicker Method
extension RegisterViewController: UIImagePickerControllerDelegate, UINavigationControllerDelegate
{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        print("didFinishPickingMediaWithInfo")
        let imageProfile = (info[UIImagePickerControllerOriginalImage] as! UIImage)
        dismiss(animated: true) {
            self.imgviewProfile?.image = imageProfile
            self.imgdata = UIImageJPEGRepresentation(imageProfile, 0.5)!
        }
    }

    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        self.dismiss(animated: true, completion: nil)
    }
}

// MARK: - TextField Delegate Method
extension RegisterViewController: UITextFieldDelegate
{
    func textFieldDidBeginEditing(_ textField: UITextField) {
        activeField = textField;
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        activeField = nil;
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool{
        if activeField == txtFirstName {
            txtMobile.becomeFirstResponder()
        }
        else if activeField == txtMobile{
            txtEmail.becomeFirstResponder()
        }
        else if activeField == txtEmail{
            txtPassword.becomeFirstResponder()
        }
        else if activeField == txtPassword{
            textField.resignFirstResponder()
        }
        return true
    }
    
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool{
        return true
    }
    
    func textFieldShouldBeginEditing(_ textField: UITextField) -> Bool {
        textField.autocorrectionType = .no;
        return true
    }
}
