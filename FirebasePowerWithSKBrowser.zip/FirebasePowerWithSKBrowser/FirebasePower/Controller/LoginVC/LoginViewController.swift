//
//  LoginViewController.swift
//  Kitchen🍴Credencys
//
//  Created by piyush sinroja on 20/06/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit
import Firebase

class LoginViewController: UIViewController {

     // MARK: -  UIView Outlet
    @IBOutlet weak var viewLogin: UIView!
    @IBOutlet weak var viewEmail: UIView!
    @IBOutlet weak var viewPassword: UIView!
    
    // MARK: -  UIButton Outlet
    
    @IBOutlet weak var btnSkipLogin: UIButton!
    @IBOutlet weak var btnSignIn: UIButton!
    
    // MARK: -  UITextField Outlet

    @IBOutlet weak var txtEmail: UITextField!
    @IBOutlet weak var txtPassword: UITextField!
    
    // MARK: - Other
    var validationDic: NSDictionary!
    var validationmessageDic: NSDictionary!
    
    // MARK: -  ViewDidLoad
    
    override func viewDidLoad() {
        super.viewDidLoad()

        StrucBorderColor.Bordercolor(obje: btnSignIn)
        StrucBorderColor.Bordercolor(obje: btnSkipLogin)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: -  TextField Method
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // MARK: -  Button Actions
    
    @IBAction func btnSignIn(_ sender: AnyObject) {
        CheckTextfieldValidation(senderstr: "btnSubmit")
    }
    
    // MARK:- Auth with Firebase account
    func authWithFirebaseLogin() {
        FIRAuth.auth()?.signIn(withEmail: self.txtEmail.text!, password: self.txtPassword.text!, completion: { (user, error) in
            if let err:Error = error
            {
                self.showAlertWithMessage("Login Unsuccessful :( \n Error \(err.localizedDescription)")
                return
            }
            
            self.showAlertWithMessage("Login successful!\n Your User id is \(user?.uid)")
            if let useragain = FIRAuth.auth()?.currentUser {
                print(useragain.displayName ?? "")
                print(useragain.uid)
                print(useragain.email ?? "")
                print(useragain.photoURL ?? "")
                
                if let name = useragain.displayName {
                    print(name)
                    
                }

                if let urlphoto = useragain.photoURL {
                    //self.imgView?.imageURL = urlphoto
                    print(urlphoto)
                
                }
            }
        })
    }

    func CheckTextfieldValidation(senderstr: String){
        validationDic = ["Email": txtEmail.text!, "Password" : txtPassword.text!]
        validationmessageDic = ["Email": alertmessage.EmailId, "Password" :alertmessage.Password]
        let check: Bool =  Constant.CheckAllTextValidation(dictextfield: validationDic, dicValidationmessage: validationmessageDic)
        if check == true {
            authWithFirebaseLogin()
        }
        else {
            return
        }
    }
    
    @IBAction func btnSkipLogin(_ sender: AnyObject) {
        let maincontentVC : DLDemoRootViewController = self.storyboard?.instantiateViewController(withIdentifier: "DLDemoRootViewController") as!  DLDemoRootViewController
        self.navigationController?.pushViewController(maincontentVC, animated: true)
    }
}

// MARK: -  StrucBorderColor
struct StrucBorderColor {
    static func Bordercolor(obje: AnyObject) {
        obje.layer.cornerRadius  = 10
        obje.layer.borderWidth = 1.0
       // obje.layer.borderColor = UIColor.whiteColor().CGColor
        obje.layer.masksToBounds = true
    }
}
