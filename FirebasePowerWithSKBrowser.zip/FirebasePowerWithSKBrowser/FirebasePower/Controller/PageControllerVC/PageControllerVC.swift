//
//  ViewController.swift
//  Kitchen🍴Credencys
//
//  Created by piyush sinroja on 18/06/16.
//  Copyright © 2016 piyush sinroja. All rights reserved.
//

import UIKit

class PageControllerVC: UIViewController, UITextFieldDelegate {

    //MARK: - Button Outlet
    @IBOutlet weak var segmentLogin: UIButton!
    @IBOutlet weak var segmentRegister: UIButton!
    
    //MARK: - UIImageView Outlet
    @IBOutlet weak var imgBackground: UIImageView!
    
    //MARK: -  UIView Outlet
    @IBOutlet weak var viewSegment: UIView!
    @IBOutlet weak var viewPageview: UIView!
    
    //MARK: - UILabel Outlet
    @IBOutlet weak var lblSlider: UILabel!
    
    //MARK: - UIPageControl Outlet
    var pageControldot: UIPageControl!
    internal var pageController: UIPageViewController = UIPageViewController()
    
    //MARK: -  Other
    let appDelegateobj = UIApplication.shared.delegate as! AppDelegate
    var indicatorindex: Int!
    
    //MARK: - ViewDidLoad
    override func viewDidLoad() {
        super.viewDidLoad()
        self.lblSlider.frame = CGRect(x: self.segmentLogin.frame.origin.x, y: self.lblSlider.frame.origin.y, width: self.segmentLogin.frame.size.width, height: 3)
        PageviewcontrollerSetup()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    //MARK: - PageControllerMethod
    func PageviewcontrollerSetup()  {
        indicatorindex=0;
        self.pageController = UIPageViewController(transitionStyle: .scroll, navigationOrientation: .horizontal, options: nil)
        self.pageController.dataSource = self
        self.pageController.delegate = self
        self.pageController.view!.frame = CGRect(x: 0, y: 0, width: self.viewPageview.frame.size.width, height: self.viewPageview.frame.size.height+39)
        // subViews From Pageviewcontroller
        var subviews: [AnyObject] = self.pageController.view.subviews
        for i in 0 ..< subviews.count {
            if (subviews[i] is UIPageControl) {
                pageControldot = (subviews[i] as! UIPageControl)
            }
            else {
                let scroll: UIScrollView = subviews[i] as! UIScrollView
                scroll.delegate = self
                scroll.bounces = true
            }
        }
        
                // Default pagecontrol from pageviewcontroller
        pageControldot = UIPageControl.appearance()
        pageControldot.backgroundColor = UIColor.clear
        pageControldot.isHidden = true
        
        let viewControllers: NSArray  = [Constant.loginVC]
        self.pageController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: true, completion: { _ in })
        self.addChildViewController(self.pageController)
        self.viewPageview!.addSubview(self.pageController.view!)
        self.pageController.didMove(toParentViewController: self)
        print("\(self.pageController.view.frame.size.height)")
        
    }
    
    //MARK: -  Button Actions
    
    @IBAction func segmentLogin(_ sender: AnyObject) {
        let viewControllers: NSArray  = [Constant.loginVC]
        self.pageController.setViewControllers(viewControllers as? [UIViewController], direction: .reverse, animated: true, completion: { _ in })
        
        UIView.animate(withDuration: 0.5) {
            self.lblSlider.frame = CGRect(x:self.segmentLogin.frame.origin.x, y: self.lblSlider.frame.origin.y, width: self.segmentLogin.frame.size.width, height: 3)}
    }
    
    @IBAction func segmentRegister(_ sender: Any) {
        let viewControllers: NSArray  = [Constant.registerVC]
        self.pageController.setViewControllers(viewControllers as? [UIViewController], direction: .forward, animated: true, completion: { _ in })
        
        UIView.animate(withDuration: 0.5) {
            self.lblSlider.frame = CGRect(x: self.segmentRegister.frame.origin.x, y: self.lblSlider.frame.origin.y, width: self.segmentRegister.frame.size.width, height: 3)
        }

    }
}

extension PageControllerVC : UIPageViewControllerDataSource {
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerBefore viewController: UIViewController) -> UIViewController? {
        
        if (self.pageController.viewControllers![0] == Constant.registerVC) {
            indicatorindex=1;
            return Constant.loginVC;
        }

        else if (self.pageController.viewControllers![0] == Constant.loginVC){
            indicatorindex=0;
            return nil;
        }
        return nil;
    }
    
    func pageViewController(_ pageViewController: UIPageViewController, viewControllerAfter viewController: UIViewController) -> UIViewController? {
        
        if (self.pageController.viewControllers![0] == Constant.loginVC){
            indicatorindex=0;
            return Constant.registerVC;
        }
        else if (self.pageController.viewControllers![0] == Constant.registerVC){
            indicatorindex=1;
            return nil;
        }
        return nil
    }
    
    func presentationCountForPageViewController(pageViewController: UIPageViewController) -> Int {
        return 2
    }
    
    func presentationIndexForPageViewController(pageViewController: UIPageViewController) -> Int {
        return indicatorindex!
    }
}

extension PageControllerVC : UIPageViewControllerDelegate {
    func pageViewController(_ pageViewController: UIPageViewController, didFinishAnimating finished: Bool, previousViewControllers: [UIViewController], transitionCompleted completed: Bool) {
        guard completed else { return }
        
        print(indicatorindex)
        print(pageViewController.viewControllers?.first?.view ?? "")
        indicatorindex = pageViewController.viewControllers!.first!.view.tag
        print("didFinishAnimating index = \(indicatorindex)")
        
        if indicatorindex == 1 {
            UIView.animate(withDuration: 0.3) {
                self.lblSlider.frame = CGRect(x: self.segmentLogin.frame.origin.x, y: self.lblSlider.frame.origin.y, width: self.segmentLogin.frame.size.width, height: 3)
            }}
        else{
            UIView.animate(withDuration: 0.3) {
                self.lblSlider.frame = CGRect(x:self.segmentRegister.frame.origin.x, y: self.lblSlider.frame.origin.y, width: self.segmentRegister.frame.size.width, height: 3)
            }}
    }
}

// MARK: -  UIScrollViewDelegate
extension PageControllerVC : UIScrollViewDelegate {
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        print(scrollView.contentOffset.x)
    }
}
