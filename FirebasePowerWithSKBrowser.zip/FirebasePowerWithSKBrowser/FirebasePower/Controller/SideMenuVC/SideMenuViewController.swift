//
//  SideMenuViewController.swift
//  DLHamburguerMenu
//
//  Created by Nacho on 5/3/15.
//  Copyright (c) 2015 Ignacio Nieto Carvajal. All rights reserved.
//

import UIKit
import Firebase

class SideMenuViewController: UIViewController {
    // outlets
    
    @IBOutlet weak var imgViewProfile: RemoteImageView!
    var cellObj : SideMenuTblCell = SideMenuTblCell()
    var arrMenuItem: [String] = [String]()
    @IBOutlet weak var tblView: UITableView!
    
    @IBOutlet weak var lblName: UILabel!
    
    @IBAction func btnEditProfile(_ sender: Any) {
        self.navigationController?.pushViewController(Constant.editProfileVC, animated: true)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    // Do any additional setup after loading the view.
        arrMenuItem = ["Home", "About Us", "Products", "Gallary", "Contact Us"]
        
        imgViewProfile.layer.cornerRadius = imgViewProfile.frame.size.width/2
        imgViewProfile.layer.masksToBounds = true
        imgViewProfile.layer.borderColor = UIColor.white.cgColor
        imgViewProfile.layer.borderWidth = 1.0
        lblName.text = "Piyush Sinroja"
    }

    override func viewWillAppear(_ animated: Bool) {
        if let useragain = FIRAuth.auth()?.currentUser {
            if let name = useragain.displayName {
                 lblName.text = name
            }
            if let urlphoto = useragain.photoURL {
                imgViewProfile.imageURL = urlphoto
            }
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

extension SideMenuViewController : UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrMenuItem.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        cellObj = tblView.dequeueReusableCell(withIdentifier: "SideMenuTblCell") as! SideMenuTblCell
        cellObj.lblMenuItems.text = arrMenuItem[indexPath.row]
        return cellObj
    }
}

extension SideMenuViewController : UITableViewDelegate {
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        switch indexPath.row {
        case 0:
            Constant.goToHomeViewController(selfnew: self)
        case 1:
            Constant.goToAboutUsViewController(selfnew: self)
        case 2:
            print("2")
        case 3:
            Constant.goToGallaryViewController(selfnew: self)
        case 4:
            print("4")
        default:
            return
        }
    }
}
