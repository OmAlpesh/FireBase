//
//  SideMenuTblCell.swift
//  FirebasePower
//
//  Created by piyush sinroja on 27/02/17.
//  Copyright © 2017 Piyush. All rights reserved.
//

import UIKit

class SideMenuTblCell: UITableViewCell {

    
    @IBOutlet weak var lblMenuItems: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
